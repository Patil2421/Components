﻿using System;
using System.Drawing;
using CoreGraphics;
using Foundation;
using Champagn;
using Champagn.iOS;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(ImageCropperPage), typeof(CropPageRenderer))]
namespace Champagn.iOS
{
	public class CropPageRenderer : PageRenderer
	{
		UIImageView imageView;
		CropperView cropperView;
		UIPanGestureRecognizer pan;
		UIPinchGestureRecognizer pinch;
		UITapGestureRecognizer doubleTap;
		ImageCropperPage page;
		byte[] croppedImageData;
		UIButton btnSave;
		nfloat oldWidth;
		nfloat oldHeight;
		nfloat newWidth;
		nfloat newHeight;

		protected override void OnElementChanged(VisualElementChangedEventArgs e)
		{
			base.OnElementChanged(e);

			page = e.NewElement as ImageCropperPage;
			var view = NativeView;

			btnSave = new UIButton(new CGRect(0, view.Frame.Height - 50, view.Frame.Width, 50));
			btnSave.BackgroundColor = UIColor.Black;
			btnSave.SetTitleColor(UIColor.White, UIControlState.Normal);
			if (page != null)
			{
				btnSave.SetTitle("Crop", UIControlState.Normal);
			}
			btnSave.TouchUpInside += BtnSaveTouchUpInside;
			view.Add(btnSave);
		}

		public override void ViewDidLoad()
		{
			base.ViewDidLoad();
			var data = NSData.FromArray(page.imgSource);
			using (var image = UIImage.LoadFromData(data))
			{
				oldWidth = image.Size.Width;
				oldHeight = image.Size.Height;
				nfloat screenWidth = UIScreen.MainScreen.Bounds.Width;
				newWidth = screenWidth;
				newHeight = (newWidth * oldHeight) / oldWidth;
				imageView = new UIImageView(new CGRect(0, (UIScreen.MainScreen.Bounds.Height - newHeight) / 2, newWidth, newHeight));
				imageView.Image = image;
			}
			cropperView = new CropperView
			{
				Frame = imageView.Frame
			};
			View.AddSubviews(imageView, cropperView);

			nfloat dx = 0;
			nfloat dy = 0;

			pan = new UIPanGestureRecognizer(() =>
			{
				if ((pan.State == UIGestureRecognizerState.Began || pan.State == UIGestureRecognizerState.Changed) && (pan.NumberOfTouches == 1))
				{
					var p0 = pan.LocationInView(View);
					if (dx == 0)
						dx = p0.X - cropperView.Origin.X;
					if (dy == 0)
						dy = p0.Y - cropperView.Origin.Y;
					var p1 = new CGPoint(p0.X - dx, p0.Y - dy);
					cropperView.Origin = p1;
				}
				else if (pan.State == UIGestureRecognizerState.Ended)
				{
					dx = 0;
					dy = 0;
				}
			});
			cropperView.AddGestureRecognizer(pan);
		}

		void BtnSaveTouchUpInside(object sender, EventArgs e)
		{
			Crop();
		}

		void Crop()
		{
			CGSize cgh = new CGSize(newWidth, newHeight);
			var inputCGImage = imageView.Image.Scale(cgh).CGImage;
			var updatedImage = inputCGImage.WithImageInRect(cropperView.CropRect);
			if (updatedImage != null)
			{
				using (var croppedImage = UIImage.FromImage(updatedImage))
				{
					imageView.Image = croppedImage;
					imageView.Frame = cropperView.CropRect;
					imageView.Center = View.Center;
					cropperView.Origin = new CGPoint(imageView.Frame.Left, imageView.Frame.Top);
					cropperView.Hidden = true;
					using (NSData imageData = croppedImage.AsPNG())
					{
						byte[] myByteArray = new byte[imageData.Length];
						System.Runtime.InteropServices.Marshal.Copy
							  (imageData.Bytes, myByteArray, 0, Convert.ToInt32(imageData.Length));
						if (myByteArray != null)
						{
							if (myByteArray.Length > (1024 * Constants.TemplateImageMaxSize))
							{
								croppedImageData = ResizeImage(myByteArray, Constants.CroppedImageWidth, Constants.CroppedImageHeight);
								App.bufferTest = croppedImageData;
							}
							else
							{
								App.bufferTest = myByteArray;
							}
						}
					}
				}
				btnSave.RemoveFromSuperview();
			}
		}


		internal static ImageSource GetImageSourceFromUIImage(UIImage uiImage)
		{
			return uiImage == null ? null : ImageSource.FromStream(() => uiImage.AsJPEG(0.75f).AsStream());
		}

		public byte[] ResizeImage(byte[] imageData, int width, int height)
		{
			// Original image properties
			UIImage originalImage = ImageFromByteArray(imageData);
			var sourceSize = originalImage.Size;

			// Resized image max width and height
			float maxWidth = width;
			float maxHeight = height;

			// Calculate ratio
			var maxResizeFactor = Math.Max(maxWidth / sourceSize.Width, maxHeight / sourceSize.Height);
			if (maxResizeFactor > 1)
			{
				return originalImage.AsPNG().ToArray();
			}
			else
			{
				// Resized image dimensions
				var newImgWidth = (float)maxResizeFactor * (float)sourceSize.Width;
				var newImgHeight = (float)maxResizeFactor * (float)sourceSize.Height;

				// Resized image
				UIGraphics.BeginImageContext(new SizeF(newImgWidth, newImgHeight));
				originalImage.Draw(new RectangleF(0, 0, newImgWidth, newImgHeight));
				var resultImage = UIGraphics.GetImageFromCurrentImageContext();
				UIGraphics.EndImageContext();

				// Return byte data of resized image
				return resultImage.AsPNG().ToArray();
			}
		}

		/// <summary>
		/// Returns image file from byte data
		/// </summary>
		/// <param name="data"></param>
		/// <returns></returns>
		public static UIKit.UIImage ImageFromByteArray(byte[] data)
		{
			if (data == null)
				return null;

			UIKit.UIImage image;
			try
			{
				image = new UIKit.UIImage(Foundation.NSData.FromArray(data));
			}
			catch
			{
				return null;
			}
			return image;
		}
	}
}