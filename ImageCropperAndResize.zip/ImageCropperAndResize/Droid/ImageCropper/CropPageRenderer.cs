﻿using Android.App;
using Android.Content;
using Champagn;
using Champagn.Droid;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(ImageCropperPage), typeof(CropPageRenderer))]
namespace Champagn.Droid
{
	public class CropPageRenderer : PageRenderer
	{
		ImageCropperPage page;
		protected override void OnElementChanged(ElementChangedEventArgs<Page> e)
		{
			base.OnElementChanged(e);

			var activity = this.Context as Activity;
			page = e.NewElement as ImageCropperPage;
			Intent intent = new Intent(activity, typeof(CropImage));
			intent.PutExtra("image-path", page.file);
			intent.PutExtra("scale", true);
			intent.SetFlags(ActivityFlags.NewTask);

			activity.StartActivity(intent);
			page.androidActivity = true;
		}

		protected override void OnElementPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			base.OnElementPropertyChanged(sender, e);
			page.ClassId = "1";
		}

	}
}



