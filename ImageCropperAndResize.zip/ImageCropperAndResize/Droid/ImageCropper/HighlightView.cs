﻿using Android.Graphics;
using Android.Graphics.Drawables;
using Android.Views;
using System;

namespace Champagn.Droid
{
	public class HighlightView
	{
		private readonly View context;

		public enum ModifyMode
		{
			None,
			Move,
			Grow
		}

		private ModifyMode mode = ModifyMode.None;

		private RectF imageRect;  // in image space
		RectF cropRect;  // in image space
		public Matrix matrix;

		private bool maintainAspectRatio;
		private float initialAspectRatio;

		private Drawable resizeDrawableWidth;
		private Drawable resizeDrawableHeight;

		private readonly Paint focusPaint = new Paint();
		private readonly Paint noFocusPaint = new Paint();
		private readonly Paint outlinePaint = new Paint();

		[Flags]
		public enum HitPosition
		{
			None,
			GrowLeftEdge,
			GrowRightEdge,
			GrowTopEdge,
			GrowBottomEdge,
			Move
		}

		#region Constructor

		public HighlightView(View ctx)
		{
			context = ctx;
		}

		#endregion

		#region Properties

		public bool Focused
		{
			get;
			set;
		}

		public bool Hidden
		{
			get;
			set;
		}

		public Rect DrawRect  // in screen space
		{
			get;
			private set;
		}

		// Returns the cropping rectangle in image space.
		public Rect CropRect
		{
			get
			{
				return new Rect((int)cropRect.Left, (int)cropRect.Top,
								(int)cropRect.Right, (int)cropRect.Bottom);
			}
		}

		public ModifyMode Mode
		{
			get
			{
				return mode;
			}
			set
			{
				if (value != mode)
				{
					mode = value;
					context.Invalidate();
				}
			}
		}

		#endregion

		#region Public methods

		// Handles motion (dx, dy) in screen space.
		// The "edge" parameter specifies which edges the user is dragging.
		public void HandleMotion(HitPosition edge, float DX, float DY)
		{
			float dx = DX;
			float dy = DY;
			Rect r = ComputeLayout();
			if (edge == HitPosition.None)
			{
				return;
			}
			else if (edge == HitPosition.Move)
			{
				// Convert to image space before sending to moveBy().
				MoveBy(dx * (cropRect.Width() / r.Width()),
					   dy * (cropRect.Height() / r.Height()));
			}
			else
			{
				if (!edge.HasFlag(HitPosition.GrowLeftEdge) && !edge.HasFlag(HitPosition.GrowRightEdge))
				{
					dx = 0;
				}

				if (!edge.HasFlag(HitPosition.GrowTopEdge) && !edge.HasFlag(HitPosition.GrowBottomEdge))
				{
					dy = 0;
				}

				// Convert to image space before sending to growBy().
				float xDelta = dx * (cropRect.Width() / r.Width());
				float yDelta = dy * (cropRect.Height() / r.Height());

				GrowBy((edge.HasFlag(HitPosition.GrowLeftEdge) ? -1 : 1) * xDelta,
					   (edge.HasFlag(HitPosition.GrowTopEdge) ? -1 : 1) * yDelta);
			}
		}

		public void Draw(Canvas canvas)
		{
			if (Hidden)
			{
				return;
			}

			canvas.Save();


			if (!Focused)
			{
				outlinePaint.Color = Color.White;
				canvas.DrawRect(DrawRect, outlinePaint);
			}
			else
			{
				Rect viewDrawingRect = new Rect();
				context.GetDrawingRect(viewDrawingRect);

				outlinePaint.Color = Color.White;
				focusPaint.Color = new Color(50, 50, 50, 125);

				Path path = new Path();
				path.AddRect(new RectF(DrawRect), Path.Direction.Cw);

				canvas.ClipPath(path, Region.Op.Difference);
				canvas.DrawRect(viewDrawingRect, focusPaint);

				canvas.Restore();
				canvas.DrawPath(path, outlinePaint);

				if (mode == ModifyMode.Grow)
				{
					resizeDrawableHeight.Draw(canvas);
				}
			}
		}

		// Determines which edges are hit by touching at (x, y).
		public HitPosition GetHit(float x, float y)
		{
			Rect r = ComputeLayout();
			var retval = HitPosition.None;
			if (retval == HitPosition.None && r.Contains((int)x, (int)y))
			{
				retval = HitPosition.Move;
			}
			return retval;
		}

		public void Invalidate()
		{
			DrawRect = ComputeLayout();
		}

		public void Setup(Matrix m, Rect imageRectP, RectF cropRectP, bool maintainAspectRatioP)
		{
			matrix = new Matrix(m);

			this.cropRect = cropRectP;
			this.imageRect = new RectF(imageRectP);
			this.maintainAspectRatio = maintainAspectRatioP;

			initialAspectRatio = cropRectP.Width() / cropRectP.Height();
			DrawRect = ComputeLayout();

			focusPaint.SetARGB(125, 50, 50, 50);
			noFocusPaint.SetARGB(125, 50, 50, 50);
			outlinePaint.StrokeWidth = 3;
			outlinePaint.SetStyle(Paint.Style.Stroke);
			outlinePaint.AntiAlias = true;

			mode = ModifyMode.None;
			Init();
		}

		#endregion

		#region Private helpers

		private void Init()
		{
			//Will do something after sometime
		}

		// Grows the cropping rectange by (dx, dy) in image space.
		private void MoveBy(float dx, float dy)
		{
			Rect invalRect = new Rect(DrawRect);

			cropRect.Offset(dx, dy);

			cropRect.Offset(
				Math.Max(0, imageRect.Left - cropRect.Left),
				Math.Max(0, imageRect.Top - cropRect.Top));

			cropRect.Offset(
				Math.Min(0, imageRect.Right - cropRect.Right),
				Math.Min(0, imageRect.Bottom - cropRect.Bottom));

			DrawRect = ComputeLayout();
			invalRect.Union(DrawRect);
			invalRect.Inset(-10, -10);
			context.Invalidate(invalRect);
		}

		// Grows the cropping rectange by (dx, dy) in image space.
		private void GrowBy(float DX, float DY)
		{
			float dx = DX;
			float dy = DY;
			if (maintainAspectRatio)
			{
				if (dx > 0 || dx < 0)
				{
					dy = dx / initialAspectRatio;
				}
				else if (dy > 0 || dy < 0)
				{
					dx = dy * initialAspectRatio;
				}
			}

			// Don't let the cropping rectangle grow too fast.
			// Grow at most half of the difference between the image rectangle and
			// the cropping rectangle.
			RectF r = new RectF(cropRect);
			if (dx > 0F && r.Width() + 2 * dx > imageRect.Width())
			{
				float adjustment = (imageRect.Width() - r.Width()) / 2F;
				dx = adjustment;
				if (maintainAspectRatio)
				{
					dy = dx / initialAspectRatio;
				}
			}
			if (dy > 0F && r.Height() + 2 * dy > imageRect.Height())
			{
				float adjustment = (imageRect.Height() - r.Height()) / 2F;
				dy = adjustment;
				if (maintainAspectRatio)
				{
					dx = dy * initialAspectRatio;
				}
			}

			r.Inset(-dx, -dy);

			// Don't let the cropping rectangle shrink too fast.
			float widthCap = 25F;
			if (r.Width() < widthCap)
			{
				r.Inset(-(widthCap - r.Width()) / 2F, 0F);
			}
			float heightCap = maintainAspectRatio
				? (widthCap / initialAspectRatio)
					: widthCap;
			if (r.Height() < heightCap)
			{
				r.Inset(0F, -(heightCap - r.Height()) / 2F);
			}

			// Put the cropping rectangle inside the image rectangle.
			if (r.Left < imageRect.Left)
			{
				r.Offset(imageRect.Left - r.Left, 0F);
			}
			else if (r.Right > imageRect.Right)
			{
				r.Offset(-(r.Right - imageRect.Right), 0);
			}
			if (r.Top < imageRect.Top)
			{
				r.Offset(0F, imageRect.Top - r.Top);
			}
			else if (r.Bottom > imageRect.Bottom)
			{
				r.Offset(0F, -(r.Bottom - imageRect.Bottom));
			}

			cropRect.Set(r);
			DrawRect = ComputeLayout();
			context.Invalidate();
		}

		// Maps the cropping rectangle from image space to screen space.
		private Rect ComputeLayout()
		{
			RectF r = new RectF(cropRect.Left, cropRect.Top,
								cropRect.Right, cropRect.Bottom);
			matrix.MapRect(r);
			return new Rect((int)Math.Round(r.Left), (int)Math.Round(r.Top),
							(int)Math.Round(r.Right), (int)Math.Round(r.Bottom));
		}

		#endregion
	}
}