﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Provider;
using Android.Util;
using Android.Views;
using Android.Widget;
using System;
using System.IO;

namespace Champagn.Droid
{
	/// <summary>
	/// The activity can crop specific region of interest from an image.
	/// </summary>
	[Activity]
	public class CropImage : MonitoredActivity
	{

		#region Private members

		// These are various options can be specified in the intent.
		private Bitmap.CompressFormat outputFormat = Bitmap.CompressFormat.Jpeg;
		private Android.Net.Uri saveUri;
		private int aspectX, aspectY;
		private readonly Handler mHandler = new Handler();
		private readonly CropPageRenderer test = new CropPageRenderer();
		// These options specifiy the output image size and whether we should
		// scale the output to fit it (or just crop it).
		private int outputX, outputY;
		private bool scale;
		private bool scaleUp = true;

		private CropImageView imageView;
		private Bitmap bitmap;

		private string imagePath;
		Button btnSave;
		private const int NO_STORAGE_ERROR = -1;
		private const int CANNOT_STAT_ERROR = -2;

		#endregion

		#region Properties

		public HighlightView Crop
		{
			set;
			get;
		}

		/// <summary>
		/// Whether the "save" button is already clicked.
		/// </summary>
		public bool Saving { get; set; }

		#endregion

		#region Overrides

		protected override void OnCreate(Bundle savedInstanceState)
		{
			base.OnCreate(savedInstanceState);

			RequestWindowFeature(Android.Views.WindowFeatures.NoTitle);
			SetContentView(Resource.Layout.cropimage);

			imageView = FindViewById<CropImageView>(Resource.Id.image);
			imageView.SetMaxHeight(Convert.ToInt32(Resources.Configuration.ScreenHeightDp - 40));
			imageView.SetMaxWidth(Convert.ToInt32(Resources.Configuration.ScreenLayout));
			ShowStorageToast(this);

			Bundle extras = Intent.Extras;

			if (extras != null)
			{
				imagePath = extras.GetString("image-path");

				saveUri = GetImageUri(imagePath);
				if (extras.GetString(MediaStore.ExtraOutput) != null)
				{
					saveUri = GetImageUri(extras.GetString(MediaStore.ExtraOutput));
				}

				bitmap = GetBitmap(imagePath);

				aspectX = extras.GetInt("aspectX");
				aspectY = extras.GetInt("aspectY");
				outputX = extras.GetInt("outputX");
				outputY = extras.GetInt("outputY");
				scale = extras.GetBoolean("scale", true);
				scaleUp = extras.GetBoolean("scaleUpIfNeeded", true);

				if (extras.GetString("outputFormat") != null)
				{
					outputFormat = Bitmap.CompressFormat.ValueOf(extras.GetString("outputFormat"));
				}
			}

			if (bitmap == null)
			{
				Finish();
				return;
			}

			Window.AddFlags(WindowManagerFlags.Fullscreen);

			btnSave = FindViewById<Button>(Resource.Id.save);
			btnSave.Click += (sender, e) => { OnSaveClicked(); };
			btnSave.SetTextColor(Android.Graphics.Color.White);
			btnSave.SetBackgroundColor(Android.Graphics.Color.Black);

			imageView.SetImageBitmapResetBase(bitmap, true);
			AddHighlightView();
		}

		protected override void OnDestroy()
		{
			base.OnDestroy();
			if (bitmap != null && bitmap.IsRecycled)
			{
				bitmap.Recycle();
			}
		}

		#endregion

		#region Private helpers

		private void AddHighlightView()
		{
			Crop = new HighlightView(imageView);

			int width = bitmap.Width;
			int height = bitmap.Height;

			Rect imageRect = new Rect(0, 0, width, height);

			// make the default size about 4/5 of the width or height
			int cropWidth = Math.Min(width, height) * 4 / 5;
			int cropHeight = cropWidth;

			if (aspectX != 0 && aspectY != 0)
			{
				if (aspectX > aspectY)
				{
					cropHeight = cropWidth * aspectY / aspectX;
				}
				else
				{
					cropWidth = cropHeight * aspectX / aspectY;
				}
			}

			int x = (width - cropWidth) / 2;
			int y = (height - cropHeight) / 2;

			RectF cropRect = new RectF(x, y, x + cropWidth, y + cropHeight);
			Crop.Setup(imageView.ImageMatrix, imageRect, cropRect, aspectX != 0 && aspectY != 0);

			imageView.ClearHighlightViews();
			Crop.Focused = true;
			imageView.AddHighlightView(Crop);
		}

		private Android.Net.Uri GetImageUri(String path)
		{
			return Android.Net.Uri.FromFile(new Java.IO.File(path));
		}

		private Bitmap GetBitmap(String path)
		{
			var uri = GetImageUri(path);
			System.IO.Stream ins = null;

			try
			{
				int IMAGE_MAX_SIZE = 1024;
				ins = ContentResolver.OpenInputStream(uri);

				// Decode image size
				BitmapFactory.Options o = new BitmapFactory.Options();
				o.InJustDecodeBounds = true;

				BitmapFactory.DecodeStream(ins, null, o);
				ins.Close();

				int scaling = 1;
				if (o.OutHeight > IMAGE_MAX_SIZE || o.OutWidth > IMAGE_MAX_SIZE)
				{
					scaling = (int)Math.Pow(2, (int)Math.Round(Math.Log(IMAGE_MAX_SIZE / (double)Math.Max(o.OutHeight, o.OutWidth)) / Math.Log(0.5)));
				}

				BitmapFactory.Options o2 = new BitmapFactory.Options();
				o2.InSampleSize = scaling;
				ins = ContentResolver.OpenInputStream(uri);
				Bitmap b = BitmapFactory.DecodeStream(ins, null, o2);
				ins.Close();

				return b;
			}
			catch (Exception e)
			{
				Log.Error(GetType().Name, e.Message);
			}

			return null;
		}

		private void OnSaveClicked()
		{
			// TODO this code needs to change to use the decode/crop/encode single
			// step api so that we don't require that the whole (possibly large)
			// bitmap doesn't have to be read into memory
			if (Saving)
			{
				return;
			}

			Saving = true;

			var r = Crop.CropRect;

			int width = r.Width();
			int height = r.Height();

			Bitmap croppedImage = Bitmap.CreateBitmap(width, height, Bitmap.Config.Rgb565);
			{
				Canvas canvas = new Canvas(croppedImage);
				Rect dstRect = new Rect(0, 0, width, height);
				canvas.DrawBitmap(bitmap, r, dstRect, null);
			}

			// If the output is required to a specific size then scale or fill
			if (outputX != 0 && outputY != 0)
			{
				if (scale)
				{
					// Scale the image to the required dimensions
					Bitmap old = croppedImage;
					croppedImage = Util.Transform(new Matrix(),
												  croppedImage, outputX, outputY, scaleUp);
					if (old != croppedImage)
					{
						old.Recycle();
					}
				}
				else
				{
					// Don't scale the image crop it to the size requested.
					// Create an new image with the cropped image in the center and
					// the extra space filled.              
					Bitmap b = Bitmap.CreateBitmap(outputX, outputY,
												   Bitmap.Config.Rgb565);
					Canvas canvas = new Canvas(b);

					Rect srcRect = Crop.CropRect;
					Rect dstRect = new Rect(0, 0, outputX, outputY);

					int dx = (srcRect.Width() - dstRect.Width()) / 2;
					int dy = (srcRect.Height() - dstRect.Height()) / 2;

					// If the srcRect is too big, use the center part of it.
					srcRect.Inset(Math.Max(0, dx), Math.Max(0, dy));

					// If the dstRect is too big, use the center part of it.
					dstRect.Inset(Math.Max(0, -dx), Math.Max(0, -dy));

					// Draw the cropped bitmap in the center
					canvas.DrawBitmap(bitmap, srcRect, dstRect, null);

					// Set the cropped bitmap as the new bitmap
					croppedImage.Recycle();
					croppedImage = b;
				}
			}

			// Return the cropped image directly or save it to the specified URI.
			Bundle myExtras = Intent.Extras;

			if (myExtras != null &&
				(myExtras.GetParcelable("data") != null || myExtras.GetBoolean("return-data")))
			{
				Bundle extras = new Bundle();
				extras.PutParcelable("data", croppedImage);
				SetResult(Result.Ok,
						  (new Intent()).SetAction("inline-data").PutExtras(extras));
				Finish();
			}
			else
			{
				Bitmap b = croppedImage;
				BackgroundJob.StartBackgroundJob(this, null, "Saving image", () => SaveOutput(b), mHandler);
			}
		}

		private void SaveOutput(Bitmap croppedImage)
		{
			if (saveUri != null)
			{
				try
				{
					using (var outputStream = ContentResolver.OpenOutputStream(saveUri))
					{
						if (outputStream != null)
						{
							croppedImage.Compress(outputFormat, 75, outputStream);
						}

					}
				}
				catch (Exception ex)
				{
					Log.Error(this.GetType().Name, ex.Message);
				}

				Bundle extras = new Bundle();
				SetResult(Result.Ok, new Intent(saveUri.ToString())
						  .PutExtras(extras));
			}
			else
			{
				Log.Error(this.GetType().Name, "not defined image url");
			}

			MemoryStream stream = new MemoryStream();
			croppedImage.Compress(outputFormat, 75, stream);
			byte[] byteArray = stream.GetBuffer();
			if (byteArray.Length > (1024 * Constants.TemplateImageMaxSize))
			{
				byte[] resizedImage = ResizeImage(byteArray, Constants.CroppedImageWidth, Constants.CroppedImageHeight);
				App.bufferTest = resizedImage;
			}
			else
			{
				App.bufferTest = byteArray;
			}
			test.Id = 1;
			Finish();
		}

		public byte[] ResizeImage(byte[] imageData, int width, int height)
		{
			// Load the bitmap
			Bitmap originalImage = BitmapFactory.DecodeByteArray(imageData, 0, imageData.Length);

			// Resized image max width and height
			float maxWidth = width;
			float maxHeight = height;

			// source image dimensions
			var sourceWidth = originalImage.Width;
			var sourceHeight = originalImage.Height;

			// Calculate ratio
			var maxResizeFactor = Math.Max(maxWidth / sourceWidth, maxHeight / sourceHeight);
			if (maxResizeFactor > 1)
			{
				using (MemoryStream ms = new MemoryStream())
				{
					originalImage.Compress(Bitmap.CompressFormat.Jpeg, 100, ms);
					return ms.ToArray();
				}
			}
			else
			{
				// Resized image dimensions
				var newWidth = (float)maxResizeFactor * (float)sourceWidth;
				var newHeight = (float)maxResizeFactor * (float)sourceHeight;

				// Resized image
				Bitmap resizedImage = Bitmap.CreateScaledBitmap(originalImage, (int)newWidth, (int)newHeight, false);

				// Return byte data of resized image
				using (MemoryStream ms = new MemoryStream())
				{
					resizedImage.Compress(Bitmap.CompressFormat.Png, Constants.ImageQuality, ms);
					return ms.ToArray();
				}
			}
		}

		private static void ShowStorageToast(Activity activity)
		{
			ShowStorageToast(activity, CalculatePicturesRemaining());
		}

		private static void ShowStorageToast(Activity activity, int remaining)
		{
			string noStorageText = null;

			if (remaining == NO_STORAGE_ERROR)
			{
				String state = Android.OS.Environment.ExternalStorageState;
				noStorageText = state == Android.OS.Environment.MediaChecking ? "Preparing card" : "No storage card";
			}
			else if (remaining < 1)
			{
				noStorageText = "Not enough space";
			}

			if (noStorageText != null)
			{
				Toast.MakeText(activity, noStorageText, ToastLength.Long).Show();
			}
		}

		private static int CalculatePicturesRemaining()
		{
			try
			{
				string storageDirectory = Android.OS.Environment.GetExternalStoragePublicDirectory(global::Android.OS.Environment.DirectoryPictures).ToString();
				StatFs stat = new StatFs(storageDirectory);
				float remaining = ((float)stat.AvailableBlocks
								   * (float)stat.BlockSize) / 400000F;
				return (int)remaining;
			}
			catch (Exception)
			{
				// if we can't stat the filesystem then we don't know how many
				// pictures are remaining.  it might be zero but just leave it
				// blank since we really don't know.
				return CANNOT_STAT_ERROR;
			}
		}

		#endregion
	}
}
