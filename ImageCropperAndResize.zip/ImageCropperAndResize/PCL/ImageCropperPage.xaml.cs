﻿using System;
using System.IO;
using Xamarin.Forms;

namespace Champagn
{
	public partial class ImageCropperPage : ContentPage
	{

		public byte[] imgSource;
		public string file { get; set; }
		public bool androidActivity { get; set; }

		public ImageCropperPage(byte[] imageSource, string filePath)
		{
			InitializeComponent();
			imgSource = imageSource;
			file = filePath;
			btnBack.Clicked += async (object sender, EventArgs e) =>
			 {
				 await Navigation.PopModalAsync();
			 };
			btnUse.Clicked += async (object sender, EventArgs e) =>
			 {
				 if (App.bufferTest != null)
				 {
					 SessionManager.TemplateSelectedImage = App.bufferTest;
					 App.bufferTest = null;
				 }
				 await Navigation.PopModalAsync();
			 };
			Device.OnPlatform(
			Android: () =>
			{
				TimeSpan tt = new TimeSpan(0, 0, 1);
				Device.StartTimer(tt, HandleFunc);
			});
		}

		bool HandleFunc()
		{
			if (App.bufferTest != null)
			{
				imgCrop.HeightRequest = (App.ScreenWidth / 4) * 3;
				imgCrop.WidthRequest = (App.ScreenWidth / 4) * 3;
				if (imgCrop.Source == null)
				{
					imgCrop.Source = ImageSource.FromStream(() =>
					{
						Stream ss = new MemoryStream(App.bufferTest);
						return ss;
					});
				}
			}
			return true;
		}

		protected override void OnPropertyChanged(string propertyName = null)
		{

			base.OnPropertyChanged(propertyName);
			Device.OnPlatform(
			iOS: () =>
			{
				if (App.Test != null)
				{
					imgCrop.HeightRequest = (App.ScreenWidth / 4) * 3;
					imgCrop.WidthRequest = (App.ScreenWidth / 4) * 3;
					imgCrop.Source = App.Test;
					App.Test = null;
				}

			},
			Android: () =>
			{
				if (App.bufferTest != null)
				{
					imgCrop.HeightRequest = (App.ScreenWidth / 4) * 3;
					imgCrop.WidthRequest = (App.ScreenWidth / 4) * 3;
					imgCrop.Source = ImageSource.FromStream(() =>
					{
						Stream ss = new MemoryStream(App.bufferTest);
						return ss;
					});
					App.bufferTest = null;

				}
			});
		}

	}
}

