using Android.App;
using Android.Widget;
using CrossVideoPlayer.FormsPlugin.Abstractions;
using CrossVideoPlayer.FormsPlugin.Droid;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using StageClip;
using View = Xamarin.Forms.View;

[assembly: ExportRenderer(typeof(CrossVideoPlayerView), typeof(CrossVideoPlayerViewRenderer))]

namespace CrossVideoPlayer.FormsPlugin.Droid
{
	public class CrossVideoPlayerViewRenderer : ViewRenderer
	{
		protected override void OnElementChanged(ElementChangedEventArgs<View> e)
		{
			try
			{
				base.OnElementChanged(e);
				var activity = Context as Activity;
				activity.RequestedOrientation = Android.Content.PM.ScreenOrientation.Unspecified;
				var crossVideoPlayerView = Element as CrossVideoPlayerView;

				if ((crossVideoPlayerView != null) && (e.OldElement == null))
				{
					var metrics = Resources.DisplayMetrics;
					crossVideoPlayerView.HeightRequest = metrics.WidthPixels / metrics.Density / crossVideoPlayerView.VideoScale;
					var videoView = new VideoView(activity);
					var mediaController = new MediaController(activity);
					mediaController.SetAnchorView(videoView);
					videoView.SetMediaController(mediaController);
					videoView.SetVideoPath(Android.OS.Environment.ExternalStorageDirectory.AbsolutePath + "/" + Constants.DownloadFolder + "/" + crossVideoPlayerView.VideoSource);
					videoView.Start();
					SetNativeControl(videoView);
				}
			}
			catch (System.Exception)
			{
				App.Instance.Alert(Constants.SomethingWentWrongMessage, Constants.AlertTitle, Constants.OkButtonText);
			}
		}

		protected override void OnElementPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			base.OnElementPropertyChanged(sender, e);
			CrossVideoPlayerView video = (CrossVideoPlayerView)sender;
			if (video.ClassId == "10")
			{
				var activity = Context as Activity;
				activity.RequestedOrientation = Android.Content.PM.ScreenOrientation.Landscape;
			}
		}
	}
}