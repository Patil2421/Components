﻿using System;
using System.IO;
using CrossVideoPlayer.FormsPlugin.Abstractions;
using Foundation;
using StageClip;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(CrossVideoPlayerView), typeof(CrossVideoPlayerViewRenderer))]

namespace CrossVideoPlayer.FormsPlugin.Abstractions
{

	public class CrossVideoPlayerViewRenderer : ViewRenderer<CrossVideoPlayerView, UIWebView>
	{
		protected override void OnElementChanged(ElementChangedEventArgs<CrossVideoPlayerView> e)
		{
			base.OnElementChanged(e);
			try
			{
				if (Control == null)
				{
					SetNativeControl(new UIWebView());
				}
				if (e.NewElement != null)
				{
					var documents = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
					var directoryname = Path.Combine(documents, Constants.DownloadFolder + "/" + e.NewElement.VideoSource);
					Control.LoadRequest(new NSUrlRequest(new NSUrl(directoryname, false)));
					Control.ScalesPageToFit = true;
				}
			}
			catch (Exception)
			{
				App.Instance.Alert(Constants.SomethingWentWrongMessage, Constants.AlertTitle, Constants.OkButtonText);
			}
		}
	}
}
