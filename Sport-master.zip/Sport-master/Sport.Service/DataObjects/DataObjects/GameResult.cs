﻿
namespace Sport
{
	public class GameResult : GameResultBase
	{
		public Challenge Challenge
		{
			get;
			set;
		}
	}
}