﻿namespace Sport.Mobile.Tests
{
	public class Keys
	{
		public static readonly string TestEmail = "";
		public static readonly string TestPassword = "";
		public static readonly string TestAlias = "";
	}
}