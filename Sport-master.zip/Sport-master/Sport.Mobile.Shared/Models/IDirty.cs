﻿using System;

namespace Sport.Mobile.Shared
{
	public interface IDirty
	{
		bool IsDirty
		{
			get;
			set;
		}
	}
}